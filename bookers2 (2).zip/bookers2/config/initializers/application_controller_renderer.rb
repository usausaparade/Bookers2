# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'e806f7207d170157a6706e0d3ae8592202983fcfc78fcd4e797d5644af6f735074ce9290a63706e8596ed9e28f5e2a1e8a4913a2bed41280c8d5cb4733a4a3f5'